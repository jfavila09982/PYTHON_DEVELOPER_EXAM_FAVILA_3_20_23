# favila-pythonDevExam



If you are using windows powershell run first
- Set-ExecutionPolicy Unrestricted -Force

Go to directory

- cd <project-directory/ven_exam>

Activate environment

- .\Scripts\activate

Install Requirements

- pip install -r requirements.txt

Run the project

 - python manage.py runserver

Go to url 

- http://127.0.0.1:8000/admin/

admin
root123456

Generate Car First 

- http://127.0.0.1:8000/api/car/generate/
- Click the button post to create 1000 objects data.


CRUD

- Create or View list of cars 
    http://127.0.0.1:8000/api/car/

- View details list of cars by id (UPDATE | DELETE)
    -http://127.0.0.1:8000/api/car/details/201003/
    
CONSTRAINT

- Queried by color and returned in order

  - http://127.0.0.1:8000/api/car/order_color/blue/ or <yellow> <black>


