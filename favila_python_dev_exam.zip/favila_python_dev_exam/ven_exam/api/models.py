from django.db import models





class Car(models.Model):
    COLOR_CHOICES = (
        ('red', 'Red'),
        ('blue', 'Blue'),
        ('green', 'Green'),
        ('yellow', 'Yellow'),
        ('black', 'Black'),
        ('white', 'White'),
    )
    color = models.CharField(max_length=10, choices=COLOR_CHOICES)
    make = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    year = models.IntegerField()
    position = models.IntegerField(default=0)

    class Meta:
        ordering = ['position']





# Create your models here.
