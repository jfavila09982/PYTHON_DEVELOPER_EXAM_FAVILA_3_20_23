from django.urls import path
from .views import CarsList,GenerateCarsView,CarOrderedColor,CarDetail


urlpatterns = [
    path('car/generate/',GenerateCarsView.as_view()),
    path('car/', CarsList.as_view()),
    path('car/order_color/<str:color>/',CarOrderedColor.as_view()),
    path('car/details/<int:pk>/',CarDetail.as_view()),
   
    
]


