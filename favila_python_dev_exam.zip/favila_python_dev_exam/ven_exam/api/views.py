from rest_framework import generics
from .models import Car
from .serializers import CarSerializer
from django.utils import timezone
import random

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.exceptions import ObjectDoesNotExist






#Run this First and click button 'POST' to generate bulk data 1000 objects
#http://127.0.0.1:8000/api/car/generate/


class GenerateCarsView(APIView):
    def post(self, request, format=None):

        COLOR_CHOICES = (
            ('red', 'Red'),
            ('blue', 'Blue'),
            ('green', 'Green'),
            ('yellow', 'Yellow'),
            ('black', 'Black'),
            ('white', 'White'),
        )

        car_data = []
        for i in range(1000):
            car_data.append(Car(
                color=random.choice(COLOR_CHOICES)[0],
                make=f'Make {i}',
                model=f'Model {i}',
                year=random.randint(2000, timezone.now().year),
                position=0
            ))
        try:
            Car.objects.bulk_create(car_data)
            return Response({'message': 'Successfully generated 1000 car records.'}, status=status.HTTP_201_CREATED)
        except:
            return Response({'message': 'Failed to generate car records.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    







#Returning List of all cars in API



class CarsList(generics.ListCreateAPIView):
    serializer_class = CarSerializer
    queryset = Car.objects.all()[:1000]


#Returning List of all cars order by Color 
class CarOrderedColor(APIView):
    def get(self, request, color):
        # Get all cars of the specified color ordered by color
        cars = Car.objects.filter(color=color).order_by('color')

        # Serialize the queryset of cars
        serializer = CarSerializer(cars, many=True)

        # Return the serialized data as a response
        return Response(serializer.data)


# Retrieve, update or delete a car instance
class CarDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Car.objects.all()
    serializer_class = CarSerializer

    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)


    


